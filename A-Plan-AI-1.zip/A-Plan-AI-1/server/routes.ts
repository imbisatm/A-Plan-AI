import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api, courses, topics } from "@shared/schema";
import { z } from "zod";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool, db } from "./db";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { hashPassword, comparePasswords } from "./auth_utils";
import { registerChatRoutes } from "./replit_integrations/chat";

const PostgresStore = connectPg(session);

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Session Middleware
  app.use(
    session({
      store: new PostgresStore({ pool, createTableIfMissing: true }),
      secret: process.env.SESSION_SECRET || "repl_auth_secret",
      resave: false,
      saveUninitialized: false,
      cookie: {
        secure: app.get("env") === "production",
        maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
      },
    })
  );

  // Passport Setup
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy({ usernameField: "email" }, async (email, password, done) => {
      try {
        const user = await storage.getUserByEmail(email);
        if (!user) return done(null, false, { message: "Invalid credentials" });
        const isValid = await comparePasswords(password, user.password);
        if (!isValid) return done(null, false, { message: "Invalid credentials" });
        return done(null, user);
      } catch (err) {
        return done(err);
      }
    })
  );

  passport.serializeUser((user: any, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (err) {
      done(err);
    }
  });

  // Auth Routes
  app.post(api.auth.register.path, async (req, res, next) => {
    try {
      const input = api.auth.register.input.parse(req.body);
      const existing = await storage.getUserByEmail(input.email);
      if (existing) {
        return res.status(400).json({ message: "Email already exists" });
      }
      const hashedPassword = await hashPassword(input.password);
      const user = await storage.createUser({ ...input, password: hashedPassword });
      req.login(user, (err) => {
        if (err) return next(err);
        res.status(201).json(user);
      });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      next(err);
    }
  });

  app.post(api.auth.login.path, passport.authenticate("local"), (req, res) => {
    res.json(req.user);
  });

  app.post(api.auth.logout.path, (req, res) => {
    req.logout((err) => {
      if (err) return res.status(500).json({ message: "Logout failed" });
      res.json({ message: "Logged out" });
    });
  });

  app.get(api.auth.me.path, (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Not authenticated" });
    res.json(req.user);
  });

  // Course Routes
  app.get(api.courses.list.path, async (req, res) => {
    const courseList = await storage.getCourses();
    res.json(courseList);
  });

  app.get(api.courses.get.path, async (req, res) => {
    const course = await storage.getCourse(Number(req.params.id));
    if (!course) return res.status(404).json({ message: "Course not found" });
    const topicList = await storage.getTopics(course.id);
    res.json({ ...course, topics: topicList });
  });

  // Topic Routes
  app.get(api.topics.get.path, async (req, res) => {
    const topic = await storage.getTopic(Number(req.params.id));
    if (!topic) return res.status(404).json({ message: "Topic not found" });
    const questionList = await storage.getQuestions(topic.id);
    res.json({ ...topic, questions: questionList });
  });

  app.post(api.topics.complete.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Not authenticated" });
    // @ts-ignore
    const userId = req.user.id;
    const progress = await storage.updateTopicProgress(userId, Number(req.params.id), "completed");
    res.json(progress);
  });

  // Progress Routes
  app.get(api.progress.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Not authenticated" });
    // @ts-ignore
    const userId = req.user.id;
    const progress = await storage.getUserProgress(userId);
    res.json(progress);
  });

  // Register AI Tutor routes (text-based chat)
  registerChatRoutes(app);

  // Seed Data
  seedDatabase().catch(err => console.error("Seeding failed:", err));

  return httpServer;
}

async function seedDatabase() {
  const existingCourses = await storage.getCourses();
  if (existingCourses.length > 0) return;
  
  const insertedCourses = await db.insert(courses).values([
    { name: "Mathematics (Syllabus D)", subject: "Mathematics", level: "O-Level" as const },
    { name: "Physics", subject: "Physics", level: "O-Level" as const },
    { name: "Chemistry", subject: "Chemistry", level: "O-Level" as const },
    { name: "Biology", subject: "Biology", level: "O-Level" as const },
    { name: "Add-Mathematics", subject: "Mathematics", level: "O-Level" as const },
    { name: "English Language", subject: "English", level: "O-Level" as const },
    { name: "A-Level Mathematics", subject: "Mathematics", level: "A-Level" as const },
    { name: "A-Level Physics", subject: "Physics", level: "A-Level" as const },
    { name: "SAT Math", subject: "Mathematics", level: "SAT" as const },
  ]).returning();

  const mathCourse = insertedCourses.find(c => c.name === "Mathematics (Syllabus D)");
  if (mathCourse) {
    await db.insert(topics).values([
      { courseId: mathCourse.id, name: "Number and Algebra", order: 1 },
      { courseId: mathCourse.id, name: "Geometry and Measurement", order: 2 },
      { courseId: mathCourse.id, name: "Statistics and Probability", order: 3 },
      { courseId: mathCourse.id, name: "Trigonometry", order: 4 },
    ]);
  }

  const physicsCourse = insertedCourses.find(c => c.name === "Physics");
  if (physicsCourse) {
    await db.insert(topics).values([
      { courseId: physicsCourse.id, name: "Mechanics", order: 1 },
      { courseId: physicsCourse.id, name: "Thermal Physics", order: 2 },
      { courseId: physicsCourse.id, name: "Waves and Optics", order: 3 },
      { courseId: physicsCourse.id, name: "Electricity and Magnetism", order: 4 },
    ]);
  }

  const chemistryCourse = insertedCourses.find(c => c.name === "Chemistry");
  if (chemistryCourse) {
    await db.insert(topics).values([
      { courseId: chemistryCourse.id, name: "Atomic Structure", order: 1 },
      { courseId: chemistryCourse.id, name: "Chemical Bonding", order: 2 },
      { courseId: chemistryCourse.id, name: "Stoichiometry", order: 3 },
      { courseId: chemistryCourse.id, name: "Acids and Bases", order: 4 },
    ]);
  }

  const biologyCourse = insertedCourses.find(c => c.name === "Biology");
  if (biologyCourse) {
    await db.insert(topics).values([
      { courseId: biologyCourse.id, name: "Cell Structure", order: 1 },
      { courseId: biologyCourse.id, name: "Biological Molecules", order: 2 },
      { courseId: biologyCourse.id, name: "Photosynthesis", order: 3 },
      { courseId: biologyCourse.id, name: "Inheritance", order: 4 },
    ]);
  }

  const englishCourse = insertedCourses.find(c => c.name === "English Language");
  if (englishCourse) {
    await db.insert(topics).values([
      { courseId: englishCourse.id, name: "Grammar and Usage", order: 1 },
      { courseId: englishCourse.id, name: "Reading Comprehension", order: 2 },
      { courseId: englishCourse.id, name: "Descriptive Writing", order: 3 },
      { courseId: englishCourse.id, name: "Narrative Writing", order: 4 },
    ]);
  }
}
