import { db } from "./db";
import { users, courses, topics, questions, userProgress, type User, type InsertUser, type Course, type Topic, type Question, type UserProgress } from "@shared/schema";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  // User
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Courses
  getCourses(): Promise<Course[]>;
  getCourse(id: number): Promise<Course | undefined>;

  // Topics
  getTopics(courseId: number): Promise<Topic[]>;
  getTopic(id: number): Promise<Topic | undefined>;

  // Questions
  getQuestions(topicId: number): Promise<Question[]>;

  // Progress
  getUserProgress(userId: number): Promise<UserProgress[]>;
  updateTopicProgress(userId: number, topicId: number, status: string): Promise<UserProgress>;
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Course methods
  async getCourses(): Promise<Course[]> {
    return await db.select().from(courses);
  }

  async getCourse(id: number): Promise<Course | undefined> {
    const [course] = await db.select().from(courses).where(eq(courses.id, id));
    return course;
  }

  // Topic methods
  async getTopics(courseId: number): Promise<Topic[]> {
    return await db.select().from(topics).where(eq(topics.courseId, courseId)).orderBy(topics.order);
  }

  async getTopic(id: number): Promise<Topic | undefined> {
    const [topic] = await db.select().from(topics).where(eq(topics.id, id));
    return topic;
  }

  // Question methods
  async getQuestions(topicId: number): Promise<Question[]> {
    return await db.select().from(questions).where(eq(questions.topicId, topicId));
  }

  // Progress methods
  async getUserProgress(userId: number): Promise<UserProgress[]> {
    return await db.select().from(userProgress).where(eq(userProgress.userId, userId));
  }

  async updateTopicProgress(userId: number, topicId: number, status: string): Promise<UserProgress> {
    // Upsert progress
    const [existing] = await db.select().from(userProgress).where(and(eq(userProgress.userId, userId), eq(userProgress.topicId, topicId)));

    if (existing) {
      const [updated] = await db.update(userProgress)
        .set({ status, lastStudied: new Date() })
        .where(eq(userProgress.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(userProgress)
        .values({ userId, topicId, status })
        .returning();
      return created;
    }
  }
}

export const storage = new DatabaseStorage();
