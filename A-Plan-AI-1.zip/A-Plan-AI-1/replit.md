# A-Plan AI Tutor

## Overview
A SaaS educational platform for O-Level, A-Level, and SAT students featuring AI tutoring, study planning, and progress tracking.

## Current State
- MVP with core authentication, courses, topics, and AI tutor
- Uses Replit AI Integrations for OpenAI (no API key needed)
- PostgreSQL database with Drizzle ORM

## Architecture
- **Frontend**: React + Vite + TailwindCSS + Shadcn UI
- **Backend**: Express.js with session-based auth
- **Database**: PostgreSQL via Drizzle ORM
- **AI**: OpenAI via Replit AI Integrations

## User Preferences
- Email/password authentication (bcrypt-style scrypt hashing)
- Interactive UI with AJAX/fetch (no static pages)

## Recent Changes
- 2026-02-01: Initial MVP with auth, courses, AI tutor

## Notes
- Stripe integration was dismissed by user. If payments needed later, will need to set up Stripe connector or use API key approach.
- render.yaml included for Render deployment
