import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type Course, type Topic, type UserProgress, type Question } from "@shared/schema";

export function useCourses() {
  return useQuery({
    queryKey: [api.courses.list.path],
    queryFn: async () => {
      const res = await fetch(api.courses.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch courses");
      return await res.json() as Course[];
    },
  });
}

export function useCourse(id: number) {
  return useQuery({
    queryKey: [api.courses.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.courses.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) throw new Error("Course not found");
      if (!res.ok) throw new Error("Failed to fetch course");
      return await res.json() as (Course & { topics: Topic[] });
    },
    enabled: !!id,
  });
}

export function useTopic(id: number) {
  return useQuery({
    queryKey: [api.topics.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.topics.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch topic");
      return await res.json() as (Topic & { questions: Question[] });
    },
    enabled: !!id,
  });
}

export function useCompleteTopic() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (topicId: number) => {
      const url = buildUrl(api.topics.complete.path, { id: topicId });
      const res = await fetch(url, {
        method: api.topics.complete.method,
        credentials: "include"
      });
      if (!res.ok) throw new Error("Failed to complete topic");
      return await res.json() as UserProgress;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.progress.list.path] });
    },
  });
}

export function useProgress() {
  return useQuery({
    queryKey: [api.progress.list.path],
    queryFn: async () => {
      const res = await fetch(api.progress.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch progress");
      return await res.json() as UserProgress[];
    },
  });
}
