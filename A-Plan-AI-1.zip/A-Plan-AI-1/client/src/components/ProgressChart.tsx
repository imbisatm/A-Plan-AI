import { useProgress } from "@/hooks/use-courses";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell } from "recharts";
import { Loader2 } from "lucide-react";

export function ProgressChart() {
  const { data: progress, isLoading } = useProgress();

  if (isLoading) {
    return (
      <div className="h-64 flex items-center justify-center text-muted-foreground">
        <Loader2 className="w-6 h-6 animate-spin" />
      </div>
    );
  }

  // Transform data for chart
  // This is mock logic since real data aggregation would depend on more DB joins
  // Assuming progress has topicId, we'd need topic names. For MVP using dummy labels if not populated.
  const data = progress?.map((p, i) => ({
    name: `Topic ${i + 1}`,
    score: p.score || 0,
    status: p.status
  })) || [];

  const EmptyState = () => (
    <div className="h-64 flex flex-col items-center justify-center text-muted-foreground bg-muted/20 rounded-xl border border-dashed border-border">
      <p>No study data yet.</p>
      <p className="text-sm">Complete topics to see your progress!</p>
    </div>
  );

  if (data.length === 0) return <EmptyState />;

  return (
    <div className="h-64 w-full mt-4">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data}>
          <XAxis 
            dataKey="name" 
            stroke="#888888" 
            fontSize={12} 
            tickLine={false} 
            axisLine={false} 
          />
          <YAxis 
            stroke="#888888" 
            fontSize={12} 
            tickLine={false} 
            axisLine={false} 
            tickFormatter={(value) => `${value}%`} 
          />
          <Tooltip 
            cursor={{ fill: 'transparent' }}
            content={({ active, payload }) => {
              if (active && payload && payload.length) {
                return (
                  <div className="rounded-lg border bg-background p-2 shadow-sm">
                    <div className="grid grid-cols-2 gap-2">
                      <div className="flex flex-col">
                        <span className="text-[0.70rem] uppercase text-muted-foreground">Score</span>
                        <span className="font-bold text-muted-foreground">{payload[0].value}%</span>
                      </div>
                    </div>
                  </div>
                );
              }
              return null;
            }}
          />
          <Bar dataKey="score" radius={[4, 4, 0, 0]}>
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.score >= 80 ? 'hsl(142 76% 36%)' : 'hsl(221 83% 53%)'} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
