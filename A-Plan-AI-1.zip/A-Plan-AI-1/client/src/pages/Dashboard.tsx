import { Layout } from "@/components/Layout";
import { useAuth } from "@/hooks/use-auth";
import { ProgressChart } from "@/components/ProgressChart";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight, BookOpen, MessageSquare, Target } from "lucide-react";
import { Link } from "wouter";

export default function Dashboard() {
  const { user } = useAuth();

  return (
    <Layout>
      <header className="mb-8">
        <h1 className="text-3xl font-display font-bold text-foreground">
          Welcome back, {user?.name?.split(' ')[0]}!
        </h1>
        <p className="text-muted-foreground mt-2">Ready to continue your learning journey today?</p>
      </header>

      <div className="grid md:grid-cols-3 gap-6 mb-8">
        {/* Quick Stats Cards */}
        <Card className="shadow-sm border-border/60">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Current Level</CardTitle>
            <Target className="w-4 h-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">O-Level</div>
            <p className="text-xs text-muted-foreground mt-1">Science & Math Focus</p>
          </CardContent>
        </Card>
        
        <Card className="shadow-sm border-border/60">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Topics Completed</CardTitle>
            <BookOpen className="w-4 h-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12</div>
            <p className="text-xs text-muted-foreground mt-1">+2 this week</p>
          </CardContent>
        </Card>

        <Card className="shadow-sm border-border/60">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">AI Sessions</CardTitle>
            <MessageSquare className="w-4 h-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">4.5 hrs</div>
            <p className="text-xs text-muted-foreground mt-1">Tutoring time</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Main Chart Area */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="shadow-sm border-border/60">
            <CardHeader>
              <CardTitle>Learning Progress</CardTitle>
              <CardDescription>Your quiz scores across recent topics</CardDescription>
            </CardHeader>
            <CardContent>
              <ProgressChart />
            </CardContent>
          </Card>

          {/* Recommended Actions */}
          <div className="grid sm:grid-cols-2 gap-4">
            <Link href="/courses">
              <div className="group cursor-pointer bg-gradient-to-br from-blue-50 to-indigo-50 hover:from-blue-100 hover:to-indigo-100 border border-blue-100 rounded-xl p-6 transition-all">
                <div className="flex items-center justify-between mb-4">
                  <div className="bg-white p-2.5 rounded-lg shadow-sm text-blue-600">
                    <BookOpen className="w-6 h-6" />
                  </div>
                  <ArrowRight className="w-5 h-5 text-blue-400 group-hover:translate-x-1 transition-transform" />
                </div>
                <h3 className="font-bold text-lg text-blue-900">Resume Courses</h3>
                <p className="text-blue-700/80 text-sm mt-1">Continue where you left off</p>
              </div>
            </Link>

            <Link href="/tutor">
              <div className="group cursor-pointer bg-gradient-to-br from-violet-50 to-fuchsia-50 hover:from-violet-100 hover:to-fuchsia-100 border border-violet-100 rounded-xl p-6 transition-all">
                <div className="flex items-center justify-between mb-4">
                  <div className="bg-white p-2.5 rounded-lg shadow-sm text-violet-600">
                    <MessageSquare className="w-6 h-6" />
                  </div>
                  <ArrowRight className="w-5 h-5 text-violet-400 group-hover:translate-x-1 transition-transform" />
                </div>
                <h3 className="font-bold text-lg text-violet-900">Ask AI Tutor</h3>
                <p className="text-violet-700/80 text-sm mt-1">Get help with a difficult topic</p>
              </div>
            </Link>
          </div>
        </div>

        {/* Sidebar Widgets */}
        <div className="space-y-6">
          <Card className="bg-primary text-primary-foreground shadow-lg shadow-primary/20 border-0">
            <CardHeader>
              <CardTitle>Daily Goal</CardTitle>
              <CardDescription className="text-primary-foreground/80">Complete 2 topics today</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-end gap-2 mb-2">
                <span className="text-4xl font-bold">50%</span>
                <span className="mb-1 opacity-80">completed</span>
              </div>
              <div className="h-2 bg-black/20 rounded-full overflow-hidden">
                <div className="h-full bg-white w-1/2 rounded-full" />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}
