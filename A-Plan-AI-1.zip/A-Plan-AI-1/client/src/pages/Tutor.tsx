import { Layout } from "@/components/Layout";
import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Card } from "@/components/ui/card";
import { Mic, Send, Bot, User, Volume2, StopCircle } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";

// Using the provided integration hooks via relative import
// Assuming the agent placed them at client/replit_integrations/audio
// If this path is wrong, the bundler will complain, but based on tool output it exists.
import { useVoiceRecorder, useVoiceStream } from "../../replit_integrations/audio";

interface Message {
  role: "user" | "assistant";
  content: string;
}

export default function Tutor() {
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([
    { role: "assistant", content: `Hello ${user?.name}! I'm your AI Tutor. How can I help you with your studies today?` }
  ]);
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);
  
  // Voice Integration Hooks
  const recorder = useVoiceRecorder();
  const { streamVoiceResponse, playbackState } = useVoiceStream({
    onUserTranscript: (text) => {
      // Add user's spoken text to chat immediately
      setMessages(prev => [...prev, { role: "user", content: text }]);
    },
    onTranscript: (text, full) => {
      // Update assistant's streaming response
      setMessages(prev => {
        const last = prev[prev.length - 1];
        if (last.role === "assistant" && last.content !== full) {
          // If already streaming, update last message
          return [...prev.slice(0, -1), { role: "assistant", content: full }];
        } else if (last.role === "user") {
          // New response starting
          return [...prev, { role: "assistant", content: full }];
        }
        return prev;
      });
    },
    onComplete: (finalText) => {
      // Ensure final state is set
      setMessages(prev => {
        const last = prev[prev.length - 1];
        if (last.role === "assistant") {
          return [...prev.slice(0, -1), { role: "assistant", content: finalText }];
        }
        return [...prev, { role: "assistant", content: finalText }];
      });
    }
  });

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  const [conversationId, setConversationId] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Create conversation on mount
  useEffect(() => {
    const createConversation = async () => {
      try {
        const res = await fetch("/api/conversations", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ title: "Tutor Session" }),
        });
        if (res.ok) {
          const conv = await res.json();
          setConversationId(conv.id);
        }
      } catch (error) {
        console.error("Failed to create conversation", error);
      }
    };
    createConversation();
  }, []);

  const handleSend = async () => {
    if (!input.trim() || !conversationId || isLoading) return;
    
    const userMsg = input;
    setMessages(prev => [...prev, { role: "user", content: userMsg }]);
    setInput("");
    setIsLoading(true);

    try {
      const res = await fetch(`/api/conversations/${conversationId}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: userMsg }),
      });

      if (!res.ok) throw new Error("Failed to send message");

      // Read SSE stream
      const reader = res.body?.getReader();
      const decoder = new TextDecoder();
      let fullResponse = "";

      if (reader) {
        // Add empty assistant message to update
        setMessages(prev => [...prev, { role: "assistant", content: "" }]);

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          const chunk = decoder.decode(value, { stream: true });
          const lines = chunk.split("\n");

          for (const line of lines) {
            if (line.startsWith("data: ")) {
              try {
                const data = JSON.parse(line.slice(6));
                if (data.content) {
                  fullResponse += data.content;
                  setMessages(prev => {
                    const newMessages = [...prev];
                    newMessages[newMessages.length - 1] = { role: "assistant", content: fullResponse };
                    return newMessages;
                  });
                }
              } catch {}
            }
          }
        }
      }
    } catch (error) {
      console.error("Chat error:", error);
      setMessages(prev => [...prev, { role: "assistant", content: "Sorry, I encountered an error. Please try again." }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleMicClick = async () => {
    if (!conversationId) return;
    
    if (recorder.state === "recording") {
      const blob = await recorder.stopRecording();
      await streamVoiceResponse(`/api/conversations/${conversationId}/messages`, blob);
    } else {
      await recorder.startRecording();
    }
  };

  return (
    <Layout>
      <div className="h-[calc(100vh-8rem)] flex flex-col max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-display font-bold">AI Tutor</h1>
          {playbackState === "playing" && (
            <div className="flex items-center gap-2 text-primary animate-pulse">
              <Volume2 className="w-4 h-4" />
              <span className="text-xs font-medium">Speaking...</span>
            </div>
          )}
        </div>

        <Card className="flex-1 overflow-hidden flex flex-col shadow-lg border-border/60 bg-background/50 backdrop-blur-sm">
          <ScrollArea className="flex-1 p-6">
            <div className="space-y-6">
              {messages.map((msg, i) => (
                <div
                  key={i}
                  className={cn(
                    "flex gap-4 max-w-[80%]",
                    msg.role === "user" ? "ml-auto flex-row-reverse" : "mr-auto"
                  )}
                >
                  <Avatar className={cn(
                    "w-8 h-8",
                    msg.role === "assistant" ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
                  )}>
                    <AvatarFallback>
                      {msg.role === "assistant" ? <Bot className="w-5 h-5" /> : <User className="w-5 h-5" />}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className={cn(
                    "p-4 rounded-2xl text-sm leading-relaxed shadow-sm",
                    msg.role === "assistant" 
                      ? "bg-white border border-border text-foreground" 
                      : "bg-primary text-primary-foreground"
                  )}>
                    {msg.content}
                  </div>
                </div>
              ))}
              <div ref={scrollRef} />
            </div>
          </ScrollArea>

          <div className="p-4 bg-background border-t">
            <div className="flex items-center gap-3 relative">
              <Input
                placeholder="Type your question..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSend()}
                className="pl-4 pr-12 py-6 rounded-full shadow-inner bg-muted/30 border-border/50 focus:bg-background transition-colors"
              />
              
              <div className="absolute right-2 flex items-center gap-1">
                <Button 
                  size="icon"
                  variant={recorder.state === "recording" ? "destructive" : "ghost"}
                  className={cn(
                    "rounded-full w-10 h-10 transition-all",
                    recorder.state === "recording" && "animate-pulse shadow-red-500/20 shadow-lg"
                  )}
                  onClick={handleMicClick}
                >
                  {recorder.state === "recording" ? <StopCircle className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                </Button>
                
                {input.trim() && (
                  <Button 
                    size="icon" 
                    className="rounded-full w-10 h-10 shadow-lg shadow-primary/20"
                    onClick={handleSend}
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                )}
              </div>
            </div>
            <p className="text-center text-xs text-muted-foreground mt-3">
              Press the microphone to speak with your AI Tutor
            </p>
          </div>
        </Card>
      </div>
    </Layout>
  );
}
