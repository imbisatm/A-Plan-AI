import { Layout } from "@/components/Layout";
import { useCourse } from "@/hooks/use-courses";
import { Link, useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, ArrowLeft, CheckCircle2, Circle } from "lucide-react";
import { cn } from "@/lib/utils";

export default function CourseDetail() {
  const [, params] = useRoute("/courses/:id");
  const courseId = params ? parseInt(params.id) : 0;
  const { data: course, isLoading } = useCourse(courseId);

  if (isLoading) {
    return (
      <Layout>
        <div className="flex justify-center py-20">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </Layout>
    );
  }

  if (!course) {
    return (
      <Layout>
        <div className="text-center py-20">
          <h2 className="text-2xl font-bold">Course not found</h2>
          <Link href="/courses">
            <Button variant="link">Back to courses</Button>
          </Link>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="mb-6">
        <Link href="/courses">
          <Button variant="ghost" size="sm" className="mb-4 pl-0 hover:bg-transparent hover:text-primary">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Courses
          </Button>
        </Link>
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-3xl font-display font-bold">{course.name}</h1>
            <p className="text-muted-foreground mt-2 text-lg">{course.subject} • {course.level}</p>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <h2 className="text-xl font-semibold mb-4">Course Topics</h2>
        {course.topics?.sort((a, b) => a.order - b.order).map((topic, index) => (
          <Link key={topic.id} href={`/topics/${topic.id}`}>
            <Card className="p-6 hover:shadow-md transition-all cursor-pointer border-border/60 group">
              <div className="flex items-center gap-4">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-muted flex items-center justify-center font-bold text-muted-foreground text-sm group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                  {index + 1}
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-lg group-hover:text-primary transition-colors">{topic.name}</h3>
                  <p className="text-sm text-muted-foreground">Click to start learning</p>
                </div>
                <div className="text-muted-foreground group-hover:translate-x-1 transition-transform">
                  <Circle className="w-5 h-5" />
                </div>
              </div>
            </Card>
          </Link>
        ))}
        
        {(!course.topics || course.topics.length === 0) && (
          <p className="text-muted-foreground italic">No topics available yet.</p>
        )}
      </div>
    </Layout>
  );
}
