import { Layout } from "@/components/Layout";
import { useCourses } from "@/hooks/use-courses";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, Book, ArrowRight } from "lucide-react";
import { Link } from "wouter";

export default function Courses() {
  const { data: courses, isLoading } = useCourses();

  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-3xl font-display font-bold">Available Courses</h1>
        <p className="text-muted-foreground mt-2">Select a course to start learning</p>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-20">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : courses && courses.length > 0 ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {courses.map((course) => (
            <Card key={course.id} className="group hover:shadow-lg transition-all duration-300 border-border/60 overflow-hidden" data-testid={`card-course-${course.id}`}>
              <div className="h-2 bg-primary w-0 group-hover:w-full transition-all duration-500 ease-out" />
              <CardHeader className="pb-4">
                <div className="flex justify-between items-start mb-2">
                  <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
                    <Book className="w-5 h-5" />
                  </div>
                  <Badge variant="secondary" className="font-medium">{course.level}</Badge>
                </div>
                <h3 className="text-xl font-bold font-display line-clamp-1">{course.name}</h3>
                <p className="text-muted-foreground text-sm">{course.subject}</p>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground line-clamp-2">
                  Comprehensive {course.subject} curriculum for {course.level} students.
                  Includes video lessons, quizzes, and AI support.
                </p>
              </CardContent>
              <CardFooter className="pt-2">
                <Link href={`/courses/${course.id}`} className="w-full">
                  <Button className="w-full group-hover:bg-primary/90" data-testid={`button-view-course-${course.id}`}>
                    View Topics
                    <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center py-20">
          <p className="text-muted-foreground">No courses found. Please check back later.</p>
        </div>
      )}
    </Layout>
  );
}
