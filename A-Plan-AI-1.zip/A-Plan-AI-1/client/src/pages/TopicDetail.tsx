import { Layout } from "@/components/Layout";
import { useTopic, useCompleteTopic } from "@/hooks/use-courses";
import { useRoute, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2, ArrowLeft, CheckCircle, HelpCircle } from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

export default function TopicDetail() {
  const [, params] = useRoute("/topics/:id");
  const topicId = params ? parseInt(params.id) : 0;
  const { data: topic, isLoading } = useTopic(topicId);
  const completeMutation = useCompleteTopic();
  const { toast } = useToast();
  
  // Simple state to track currently viewed question/content
  const [currentStep, setCurrentStep] = useState(0);

  if (isLoading) {
    return (
      <Layout>
        <div className="flex justify-center py-20">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      </Layout>
    );
  }

  if (!topic) return null;

  const totalSteps = (topic.questions?.length || 0);
  const progress = ((currentStep + 1) / totalSteps) * 100;

  const handleComplete = () => {
    completeMutation.mutate(topicId, {
      onSuccess: () => {
        toast({ title: "Topic Completed!", description: "Progress saved." });
      }
    });
  };

  return (
    <Layout>
      <div className="max-w-3xl mx-auto">
        <Link href={`/courses/${topic.courseId}`}>
          <Button variant="ghost" size="sm" className="mb-6 pl-0">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Course
          </Button>
        </Link>

        <div className="mb-8">
          <h1 className="text-3xl font-display font-bold">{topic.name}</h1>
          <div className="w-full bg-muted h-2 rounded-full mt-4 overflow-hidden">
            <div 
              className="bg-primary h-full transition-all duration-500" 
              style={{ width: `${progress}%` }} 
            />
          </div>
          <p className="text-sm text-muted-foreground mt-2 text-right">
            Question {currentStep + 1} of {totalSteps}
          </p>
        </div>

        {topic.questions && topic.questions.length > 0 ? (
          <div className="space-y-6">
            <Card className="border-border/60 shadow-lg">
              <CardContent className="p-8">
                <div className="flex items-start gap-4 mb-6">
                  <div className="bg-primary/10 p-2 rounded-lg text-primary">
                    <HelpCircle className="w-6 h-6" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-medium leading-relaxed">
                      {(topic.questions[currentStep].content as any).text}
                    </h3>
                  </div>
                </div>

                {/* Question Options (Mock UI) */}
                <div className="space-y-3 pl-14">
                  {((topic.questions[currentStep].content as any).options || []).map((opt: string, i: number) => (
                    <button 
                      key={i}
                      className="w-full text-left p-4 rounded-xl border border-border hover:border-primary hover:bg-primary/5 transition-all"
                    >
                      <span className="font-bold mr-3 text-muted-foreground">{String.fromCharCode(65 + i)}.</span>
                      {opt}
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>

            <div className="flex justify-between items-center pt-4">
              <Button 
                variant="outline" 
                onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
                disabled={currentStep === 0}
              >
                Previous
              </Button>
              
              {currentStep < totalSteps - 1 ? (
                <Button onClick={() => setCurrentStep(currentStep + 1)}>
                  Next Question
                </Button>
              ) : (
                <Button onClick={handleComplete} disabled={completeMutation.isPending}>
                  {completeMutation.isPending ? "Saving..." : "Complete Topic"}
                  <CheckCircle className="ml-2 w-4 h-4" />
                </Button>
              )}
            </div>
          </div>
        ) : (
          <div className="text-center py-12 bg-muted/30 rounded-2xl">
            <p className="text-muted-foreground">No questions available for this topic yet.</p>
          </div>
        )}
      </div>
    </Layout>
  );
}
