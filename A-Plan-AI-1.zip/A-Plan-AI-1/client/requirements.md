## Packages
framer-motion | Smooth layout transitions and entry animations
recharts | Data visualization for student progress
react-hook-form | Form handling for auth and inputs
zod | Schema validation
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind classes safely

## Notes
The backend has pre-configured AI and Audio routes.
AI Tutor interface connects to /api/conversations
Audio capabilities use the Replit AI integration files.
